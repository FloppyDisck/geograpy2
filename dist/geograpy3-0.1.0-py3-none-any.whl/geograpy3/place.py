
class Place:
    def __init__(self, city = None, region = None, country = None):
        self.city = city
        self.region = region
        self.country = country